package com.sohez.grocerymaster.data.db.model

data class Category(
    val category: String,
    val img: String,
)