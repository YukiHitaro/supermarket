package com.sohez.grocerymaster.data.db.model

class ListCategory : ArrayList<Category>()
