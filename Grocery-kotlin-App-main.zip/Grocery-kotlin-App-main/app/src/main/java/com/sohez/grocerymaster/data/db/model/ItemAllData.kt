package com.sohez.grocerymaster.data.db.model

class ItemAllData : ArrayList<ItemAllDataItem>()