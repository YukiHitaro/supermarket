package com.sohez.grocerymaster.adapter

class SearchViewAdapter {
}