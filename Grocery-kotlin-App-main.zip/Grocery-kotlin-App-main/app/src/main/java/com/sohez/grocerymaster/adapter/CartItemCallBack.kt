package com.sohez.grocerymaster.adapter

interface CartItemCallBack {
    fun addToCart(itemId:Long)
}